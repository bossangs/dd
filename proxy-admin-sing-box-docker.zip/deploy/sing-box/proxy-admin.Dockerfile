ARG SINGBOX_IMAGE=ghcr.io/sagernet/sing-box:v1.14.3
FROM ${SINGBOX_IMAGE} AS singbox-core
FROM python:3.12-slim

ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app.py .
COPY --from=singbox-core /usr/local/bin/sing-box /usr/local/bin/sing-box
RUN mkdir -p /app/data && useradd --system --uid 10001 appuser \
    && chown -R appuser:appuser /app
USER appuser
EXPOSE 8000
CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000", "--no-access-log"]
